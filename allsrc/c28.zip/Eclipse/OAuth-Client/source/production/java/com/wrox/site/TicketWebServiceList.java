package com.wrox.site;

import java.util.List;

public class TicketWebServiceList
{
    private List<Ticket> value;

    public List<Ticket> getValue()
    {
        return this.value;
    }

    public void setValue(List<Ticket> value)
    {
        this.value = value;
    }
}
