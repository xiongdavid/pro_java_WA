package com.wrox.site;

public enum Gender
{
    MALE, FEMALE
}
