package com.wrox.site.entities;

public enum Gender
{
    MALE,
    FEMALE,
    UNSPECIFIED
}
