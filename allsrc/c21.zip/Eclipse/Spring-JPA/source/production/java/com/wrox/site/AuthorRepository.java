package com.wrox.site;

import com.wrox.site.entities.Author;

public interface AuthorRepository extends GenericRepository<Long, Author>
{

}
