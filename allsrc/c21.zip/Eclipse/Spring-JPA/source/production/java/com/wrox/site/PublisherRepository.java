package com.wrox.site;

import com.wrox.site.entities.Publisher;

public interface PublisherRepository extends GenericRepository<Long, Publisher>
{

}
