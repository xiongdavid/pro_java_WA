package com.wrox.site;

import com.wrox.site.entities.TicketEntity;

public interface TicketRepository extends GenericRepository<Long, TicketEntity>
{
}
