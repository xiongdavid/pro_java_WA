package com.wrox;

public interface GreetingService
{
    public String getGreeting(String name);
}
