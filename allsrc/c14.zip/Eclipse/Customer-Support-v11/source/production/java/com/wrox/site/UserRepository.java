package com.wrox.site;

public interface UserRepository
{
    String getPasswordForUser(String username);
}
