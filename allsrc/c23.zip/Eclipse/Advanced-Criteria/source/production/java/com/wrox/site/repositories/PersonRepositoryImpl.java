package com.wrox.site.repositories;

import com.wrox.site.entities.Person;

public class PersonRepositoryImpl extends AbstractSearchableJpaRepository<Person>
{
}
